<?php

//$con = mysql_connect("localhost", "root", "karlik") or die(mysql_error()); 

//mysql_select_db("storagesystem") or die(mysql_error()); 

$conn = new mysqli("localhost", "root", "karlik", "storagesystem");
//$conn = new mysqli("92.48.196.79", "suleyok47_say", "karlikspor50", "suleyok47_say","1111");